package View;

import Controller.Controller;
import Model.Model;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class View extends JFrame {

    private JPanel jpNorth;
    private JPanel jpCenter;
    private JLabel jlImgS;
    private JLabel jlImgR;
    private JPanel jpSouth;
    private JButton jbConnect;

    public View() {
        setTitle("Station 2");
        setSize(500, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //NORTH
        jpNorth = new JPanel(new GridLayout(1,2));
        JLabel text1 = new JLabel("Last image sent");
        text1.setVerticalAlignment(SwingConstants.CENTER);
        text1.setHorizontalAlignment(SwingConstants.CENTER);
        jpNorth.add(text1);
        JLabel text2 = new JLabel("Last image recieved");
        text2.setVerticalAlignment(SwingConstants.CENTER);
        text2.setHorizontalAlignment(SwingConstants.CENTER);
        jpNorth.add(text2);
        getContentPane().add(jpNorth,BorderLayout.NORTH);

        //CENTER
        jpCenter = new JPanel(new GridLayout(1,2));
        jlImgS = new JLabel("No images yet");
        jlImgS.setHorizontalAlignment(SwingConstants.CENTER);
        jlImgS.setPreferredSize(new Dimension(50,50));
        jlImgR = new JLabel("No images yet");
        jlImgR.setHorizontalAlignment(SwingConstants.CENTER);
        jlImgR.setPreferredSize(new Dimension(50,50));

        jpCenter.add(jlImgS);
        jpCenter.add(jlImgR);
        getContentPane().add(jpCenter, BorderLayout.CENTER);

        //SOUTH
        jpSouth = new JPanel(new GridLayout(1,3));
        jpSouth.add(new JLabel(""));
        jpSouth.add(new JLabel(""));
        jbConnect = new JButton("Connect");
        jpSouth.add(jbConnect);
        getContentPane().add(jpSouth,BorderLayout.SOUTH);

    }

    public void registraControlador(Controller controller) {
        jbConnect.addActionListener(controller);
        jbConnect.setActionCommand("CON");
    }


    public void setSentImage(File path) {
        jlImgS.setText("");
        ImageIcon iiImage = new ImageIcon(path.toString());
        Image image = iiImage.getImage(); // transform it
        Image newimg = image.getScaledInstance(200, 150,  Image.SCALE_AREA_AVERAGING); // scale it the smooth way
        iiImage = new ImageIcon(newimg);
        jlImgS.setIcon(iiImage);
    }

    public void setReceivedImage(String path) {
        jlImgR.setText("");
        ImageIcon iiImage = new ImageIcon(path);
        Image image = iiImage.getImage(); // transform it
        Image newimg = image.getScaledInstance(200, 150,  Image.SCALE_AREA_AVERAGING); // scale it the smooth way
        iiImage = new ImageIcon(newimg);
        jlImgR.setIcon(iiImage);
    }
}
