package Model;

import java.io.File;
import java.util.LinkedList;

public class Model {

    private LinkedList<File> pathList;
    private int index;
    private int newFilesIndex;

    public Model() {
        index = 0;
        pathList = new LinkedList();
        //Busquem tots els fitxers del directori images
        File folder = new File(new File("").getAbsolutePath() + "/images");
        File[] paths = folder.listFiles();
        //Filtrem només pels fitxers jpg
        for (int i=0; i < paths.length; i++) {
            String substr = paths[i].toString().substring((int)paths[i].toString().length() - 3);
            if (substr.equals("jpg")) {
                pathList.add(paths[i]);
            }
        }
        newFilesIndex = pathList.size() + 1;

    }


    public File getPath() {
        if (index >= pathList.size()) {
            index = 0;
        }
        File path = pathList.get(index);
        return path;
    }

    public void incrementaIndex() {
        index++;
    }

    public String getNewPath() {
        File f = new File(new File("").getAbsolutePath() + "/images/img" + newFilesIndex + ".jpg");
        return f.toString();
    }

    public void incrementaNewFileIndex() {
        newFilesIndex++;
    }
}
