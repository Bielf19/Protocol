package ChaosMonkey;

import java.io.*;
import java.util.Base64;
import java.util.Random;


public class ChaosMonkey {

    private final float prob = (float) 0.5;

    public float Operation (float v1, float v2, char o) {
        Random random = new Random();
        float r = random.nextFloat();
        if (r < prob) {
            return 100;
        } else {
            switch (o){
                case '+':
                    return v1 + v2;
                case '-':
                    return v1 - v2;
                case 'x':
                    return v1 * v2;
                case '/':
                    return v1 / v2;
            }
        }


        return Float.parseFloat(null);
    }


    public void readFile(String file) {
        try {
            InputStream f = new FileInputStream(file);
            System.out.println(readFromInputStream(f));
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    private String readFromInputStream(InputStream inputStream)
            throws IOException {
        StringBuilder resultStringBuilder = new StringBuilder();
        try (BufferedReader br
                     = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                resultStringBuilder.append(line).append("\n");
            }
        }
        return resultStringBuilder.toString();
    }


    public String encoderBase64(String path) {
        String base64Image = "";
        File file = new File(path);
        try (FileInputStream imageInFile = new FileInputStream(file)) {
            byte imageData[] = new byte[(int) file.length()];
            imageInFile.read(imageData);
            //System.out.println(Integer.toBinaryString(imageData[0] & 0xFF));
            base64Image = Base64.getEncoder().encodeToString(imageData);
        } catch (FileNotFoundException e) {
            System.out.println("Image not found" + e);
        } catch (IOException ioe) {
            System.out.println("Exception while reading the Image " + ioe);
        }

        return base64Image;
    }

    public byte[] decoderBase64(String base64Image, String pathFile) {
        try (FileOutputStream imageOutFile = new FileOutputStream(pathFile)) {
            // Converting a Base64 String into Image byte array
            byte[] imageByteArray = Base64.getDecoder().decode(base64Image);

            /*    for (int i = 400; i < imageByteArray.length - 10; i+=1) {
                    if (imageByteArray[i] - 20 > - 127) {
                        imageByteArray[i] -= 20;
                    } else {
                        imageByteArray[i] += 20;
                    }
                }*/

            Random random = new Random();
            float r = random.nextFloat();
            if (r < prob) {
                imageByteArray[imageByteArray.length - imageByteArray.length/2] = 33;
            }

            imageOutFile.write(imageByteArray);
            return imageByteArray;

        } catch (FileNotFoundException e) {
            System.out.println("Image not found" + e);
        } catch (IOException ioe) {
            System.out.println("Exception while reading the Image " + ioe);
        }
        return null;
    }

    public void writeObject(Object o, ObjectOutputStream oos) {
        try {
            oos.writeObject(o);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Object readObject(ObjectInputStream ois) {
        try {
            return ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}


