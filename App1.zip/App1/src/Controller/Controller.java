package Controller;

import Model.Model;
import Network.ClientConnection;
import View.View;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

public class Controller implements ActionListener {

    private Model model;
    private View view;
    private ClientConnection networkClient;

    public Controller(Model model, View view) {
        this.model = model;
        this.view = view;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String actionCommand = e.getActionCommand();

        if (actionCommand.equals("CON")) {
            try {
                networkClient =  new ClientConnection();
            } catch (IOException p) {
                p.printStackTrace();
            }

            networkClient.IniciaConnexio(this);
        }
    }


    public String getPath() {
        return model.getPath().toString();
    }

    public void changeSentImage() {
        view.setSentImage(model.getPath());
        model.incrementaIndex();
    }

    public void changeReceivedImage(String newPath) {
        view.setReceivedImage(newPath);
    }
}
