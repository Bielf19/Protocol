package Network;



import ChaosMonkey.ChaosMonkey;
import Controller.Controller;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ClientConnection extends Thread {

    private Socket socket;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    private boolean conectat;
    private Controller controller;
    private ChaosMonkey cm = new ChaosMonkey();

    public ClientConnection() throws IOException {
        ConfiguracioClient config = new ConfiguracioClient();
        config = config.llegeixJsonClient();
        //socket = new Socket(config.getIP(), config.getPortServer());
        socket = new Socket("localhost", 2000);
        oos = new ObjectOutputStream(socket.getOutputStream());
        ois = new ObjectInputStream(socket.getInputStream());
        conectat = true;

    }

    public void IniciaConnexio(Controller controller) {
        this.controller = controller;
        if (conectat) {
            try {
                start();
            } catch (java.lang.IllegalThreadStateException e) {

            }
        }

    }

    @Override
    public void run() {

        while (conectat) {
            try {
                sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            try {
                oos.writeObject(cm.encoderBase64(controller.getPath()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            //cm.writeObject(cm.encoderBase64(controller.getPath()), oos);
            controller.changeSentImage();
            System.out.println(cm.readObject(ois).toString());
            /*try {
                oos.writeObject("Estacio 1 vol parlar amb servidor 2");
                System.out.println(ois.readObject().toString());
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }*/


        }
        //disconnect();

    }


    private void disconnect() {
        try {

            ois.close();
            oos.close();
            socket.close();
            conectat = false;

        } catch (IOException e) {

        }

        interrupt();
    }


}
