package Network;
import ChaosMonkey.ChaosMonkey;
import Controller.Controller;
import Model.Model;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ServidorDedicat extends Thread{

    private Model model;
    private Socket s;
    private Controller controller;
    private ChaosMonkey cm;


    public ServidorDedicat (Socket s, Model model, Controller controller) {
        this.model = model;
        this.s = s;
        this.controller = controller;
        cm = new ChaosMonkey();
    }


    @Override
    public void run() {
        try {
            //Creo els streams
            ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());


            while (true) {

                //String o = ois.readObject().toString();
                Object o = cm.readObject(ois);
                cm.decoderBase64(o.toString(), model.getNewPath());
                controller.changeReceivedImage(model.getNewPath());
                model.incrementaNewFileIndex();
                cm.writeObject("Image recieved by station 1", oos);
                /*
                String s = ois.readObject().toString();
                System.out.println(s);
                oos.writeObject("El servidor 1 ha rebut la petició");*/

            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}